# EXECUTIVE BEAUTY ARCHITECT CERTIFICATION
## Complete Operational Curriculum
### Ambitiously Institute

---

## PROGRAM OVERVIEW

**Program Name:** Executive Beauty Architect™ Certification
**Delivery Model:** Cohort-based with self-paced modules + live case reviews
**Duration:** 12 weeks (intensive) / 6 months (standard)
**Target Audience:** Junior → Senior → Owner level beauty professionals
**Certification:** Executive Beauty Architect™ (EBA™) designation

**Prerequisites:**
- Active esthetics or cosmetology license
- Minimum 1 year professional practice
- Foundational knowledge of skin anatomy
- Commitment to 4-6 hours weekly study

---

## LEVEL 1 — DELIVERY & LANGUAGE

### Module 1.1: The Architecture of Professional Communication

**Learning Objectives:**
- Eliminate uncertain language from professional vocabulary
- Master precise terminology for clinical authority
- Develop educator-level delivery presence
- Build systematic response frameworks

**Teaching Framework:**
1. Language audit exercise (identify weak phrasing)
2. Terminology mapping (replace vague with precise)
3. Delivery mechanics (pace, pause, emphasis)
4. Authority positioning through syntax

**Slide Deck Structure (45 slides):**
- Slide 1-5: The cost of uncertain language
- Slide 6-15: Clinical terminology library
- Slide 16-25: Delivery mechanics and vocal authority
- Slide 26-35: Response frameworks for common scenarios
- Slide 36-45: Practice drills and self-assessment

**Workbook Exercises:**
1. Personal language audit (document 20 weak phrases you use)
2. Terminology translation table (50 terms)
3. Delivery self-assessment video analysis
4. Response framework scripting

**Scripts:**
- "The barrier is compromised" (not "your skin is sensitive")
- "We're addressing inflammatory cascade first" (not "we need to calm your skin")
- "This protocol stages correction over 90 days" (not "it might take a while")

**Role Play Drills:**
1. Client says: "I've tried everything." → Architect response
2. Client says: "That's expensive." → Value translation
3. Client says: "Will this work for me?" → Expectation architecture

**Certification Assessment:**
- Recorded consultation simulation
- Language precision scorecard (minimum 85%)
- Peer review of delivery presence

---

### Module 1.2: Executive Presence Development

**Learning Objectives:**
- Command room attention without demanding it
- Develop non-verbal authority signals
- Build professional gravitas
- Master the psychology of expertise perception

**Teaching Framework:**
1. Spatial positioning and movement
2. Eye contact architecture
3. Gesture economy
4. Silence as authority tool

**Slide Deck Structure (35 slides):**
- Slides 1-10: Presence psychology research
- Slides 11-20: Non-verbal authority signals
- Slides 21-30: Executive positioning in consultation rooms
- Slides 31-35: Integration practice

**Workbook Exercises:**
1. Presence self-assessment video
2. Spatial positioning map for your treatment room
3. Gesture audit and reduction plan
4. Silence practice log

**Role Play Drills:**
1. Entering the consultation room with authority
2. Delivering difficult information with gravitas
3. Handling interruptions while maintaining presence

**Certification Assessment:**
- Video submission demonstrating executive presence
- Peer evaluation scorecard

---

## LEVEL 2 — CONSULTATION ARCHITECTURE

### Module 2.1: Layered Questioning Frameworks

**Learning Objectives:**
- Design systematic intake protocols
- Extract critical information through structured inquiry
- Build psychological safety while gathering data
- Map client responses to treatment architecture

**Teaching Framework:**
1. The three-layer question model
2. Information hierarchy mapping
3. Transition architecture between layers
4. Documentation systems for recall

**Slide Deck Structure (50 slides):**
- Slides 1-10: The cost of poor intake
- Slides 11-25: Layer 1 questions (surface history)
- Slides 26-40: Layer 2 questions (lifestyle factors)
- Slides 41-50: Layer 3 questions (psychological drivers)

**Workbook Exercises:**
1. Build your layered intake protocol (25 questions minimum)
2. Information mapping template
3. Client response categorization system
4. Transition phrase library

**Scripts:**
- Layer 1 opener: "Walk me through your skin history chronologically."
- Layer 2 transition: "Now let's understand how your daily routines intersect with what you've shared."
- Layer 3 transition: "What I'm hearing is [summary]. What would meaningful change look like for you?"

**Role Play Drills:**
1. Complete intake with resistant client
2. Intake with oversharing client
3. Intake with minimal-information client

**Certification Assessment:**
- Live intake simulation with evaluator
- Documentation quality review
- Information extraction efficiency score

---

### Module 2.2: Emotional Intelligence & Amygdala Calming

**Learning Objectives:**
- Recognize client anxiety signals
- Deploy calming techniques without losing authority
- Build trust through emotional attunement
- Navigate difficult emotional territory

**Teaching Framework:**
1. Anxiety signal recognition
2. Calming language architecture
3. Validation without agreement
4. Reframing techniques

**Slide Deck Structure (40 slides):**
- Slides 1-10: Neuroscience of client anxiety
- Slides 11-25: Calming language library
- Slides 26-35: Difficult conversation navigation
- Slides 36-40: Integration scenarios

**Workbook Exercises:**
1. Anxiety signal identification checklist
2. Personal calming phrase library (20 phrases)
3. Difficult conversation preparation template
4. Reframing practice scenarios

**Scripts:**
- "I understand this has been frustrating. Let's approach this systematically."
- "What you're experiencing is common, and it's addressable."
- "I'm going to explain what I'm seeing, and then we'll discuss the path forward."

**Role Play Drills:**
1. Client crying during consultation
2. Client expressing hopelessness
3. Client challenging your recommendations

**Certification Assessment:**
- Emotional scenario simulation
- Peer evaluation of calming effectiveness

---

### Module 2.3: Presenting Three Solution Pathways

**Learning Objectives:**
- Structure option presentation for decision clarity
- Position recommendations without pressure
- Guide clients to optimal choices through education
- Handle option comparison questions

**Teaching Framework:**
1. The three-pathway architecture
2. Option differentiation strategies
3. Decision support without steering
4. Investment conversation integration

**Slide Deck Structure (45 slides):**
- Slides 1-10: Psychology of choice architecture
- Slides 11-25: Pathway A (maintenance/conservative)
- Slides 26-40: Pathway B (corrective/moderate)
- Slides 41-45: Pathway C (intensive/aggressive)

**Workbook Exercises:**
1. Build three pathway templates for 5 common concerns
2. Investment conversation script library
3. Objection response mapping
4. Decision confirmation protocols

**Scripts:**
- "Based on what you've shared, there are three approaches we could take..."
- "Pathway A focuses on [outcome] over [timeline] at [investment level]..."
- "Which of these aligns best with your goals and timeline?"

**Role Play Drills:**
1. Presenting options to budget-conscious client
2. Presenting options to time-constrained client
3. Presenting options to overwhelmed client

**Certification Assessment:**
- Live pathway presentation simulation
- Client decision clarity score

---

## LEVEL 3 — INGREDIENT & SKIN SCIENCE TRANSLATION

### Module 3.1: Mechanism Mapping

**Learning Objectives:**
- Decode molecular mechanisms across ingredient categories
- Translate technical information into client-understandable language
- Build mechanism-based recommendation confidence
- Develop ingredient comparison frameworks

**Teaching Framework:**
1. Ingredient category classification
2. Mechanism pathway mapping
3. Translation architecture (technical → teachable)
4. Comparison framework development

**Slide Deck Structure (60 slides):**
- Slides 1-10: The importance of mechanism understanding
- Slides 11-25: Antioxidant mechanisms
- Slides 26-40: Exfoliant mechanisms
- Slides 41-50: Retinoid mechanisms
- Slides 51-60: Peptide mechanisms

**Workbook Exercises:**
1. Mechanism mapping for 50 key ingredients
2. Translation practice (technical → client language)
3. Ingredient comparison templates
4. Mechanism-based recommendation script library

**Scripts:**
- "Niacinamide works through three primary mechanisms..."
- "This ingredient interrupts the inflammatory cascade at [specific point]..."
- "Compared to [alternative], this works [mechanism difference]..."

**Role Play Drills:**
1. Explaining retinoid mechanism to concerned client
2. Comparing two similar ingredients
3. Addressing "natural vs. synthetic" questions with mechanism

**Certification Assessment:**
- Ingredient mechanism quiz (50 ingredients)
- Live translation simulation

---

### Module 3.2: Contraindication Matrices

**Learning Objectives:**
- Build systematic contraindication awareness
- Develop risk assessment protocols
- Create safe combination frameworks
- Master deferral conversations

**Teaching Framework:**
1. Contraindication category mapping
2. Risk severity classification
3. Combination safety protocols
4. Deferral language architecture

**Slide Deck Structure (55 slides):**
- Slides 1-10: The cost of contraindication oversight
- Slides 11-25: Medication contraindications
- Slides 26-40: Condition contraindications
- Slides 41-55: Combination safety matrices

**Workbook Exercises:**
1. Build personal contraindication reference guide
2. Risk assessment checklist template
3. Deferral script library (20 scenarios)
4. Combination safety quick-reference

**Scripts:**
- "Given your current [medication/condition], we need to modify our approach..."
- "I want to be transparent about timing. Here's what I recommend and why..."
- "This combination requires staging. Let me explain the sequence..."

**Role Play Drills:**
1. Deferring treatment for client on contraindicated medication
2. Explaining why two products can't be combined
3. Managing client disappointment about limitations

**Certification Assessment:**
- Contraindication scenario quiz (30 scenarios)
- Risk assessment simulation

---

### Module 3.3: pH, Layering & Sequencing

**Learning Objectives:**
- Understand pH impact on ingredient efficacy
- Build AM/PM sequencing protocols
- Develop layering architecture for maximum results
- Troubleshoot product conflict scenarios

**Teaching Framework:**
1. pH science fundamentals
2. Ingredient pH requirements
3. Sequencing logic (thinnest to thickest, pH considerations)
4. Conflict resolution protocols

**Slide Deck Structure (50 slides):**
- Slides 1-10: pH and skin function
- Slides 11-25: Ingredient pH requirements
- Slides 26-40: AM sequencing architecture
- Slides 41-50: PM corrective stacking

**Workbook Exercises:**
1. pH reference guide for 30 common ingredients
2. AM sequencing template builder
3. PM stacking protocol templates
4. Conflict troubleshooting flowchart

**Scripts:**
- "This ingredient requires a specific pH environment to activate..."
- "Here's why we sequence in this order..."
- "These two products conflict. Here's the solution..."

**Role Play Drills:**
1. Client brings in 8 products to sequence
2. Client experiencing irritation from layering
3. Client wants to add new product to existing routine

**Certification Assessment:**
- pH and sequencing quiz
- Layering protocol design simulation

---

## LEVEL 4 — TREATMENT STRUCTURING

### Module 4.1: 30-60-90 Day Protocol Architecture

**Learning Objectives:**
- Design phased treatment protocols
- Stage interventions for optimal outcomes
- Build client commitment through milestone design
- Develop protocol adjustment frameworks

**Teaching Framework:**
1. Phase objective mapping
2. Intervention staging logic
3. Milestone design for motivation
4. Adjustment trigger identification

**Slide Deck Structure (45 slides):**
- Slides 1-10: The science of phased protocols
- Slides 11-25: 30-day foundation phase
- Slides 26-40: 60-day correction phase
- Slides 41-45: 90-day optimization phase

**Workbook Exercises:**
1. Protocol template library (10 concern types)
2. Milestone design worksheet
3. Adjustment decision tree
4. Client commitment builder template

**Scripts:**
- "This protocol unfolds in three phases..."
- "At day 30, we'll assess [specific markers]..."
- "Based on your response, we may adjust [specific element]..."

**Role Play Drills:**
1. Presenting 90-day protocol to skeptical client
2. Explaining why rushing phases compromises results
3. Managing client who wants to accelerate timeline

**Certification Assessment:**
- Protocol design submission (3 case types)
- Milestone logic evaluation

---

### Module 4.2: Fitzpatrick Risk Management

**Learning Objectives:**
- Understand structural differences across Fitzpatrick types
- Develop inflammation-first protocols for higher-risk skin
- Build heat stacking awareness
- Create safe treatment parameters

**Teaching Framework:**
1. Fitzpatrick structural differences
2. PIH mechanism and prevention
3. Heat stacking risk identification
4. Safe parameter development

**Slide Deck Structure (50 slides):**
- Slides 1-10: Beyond color: structural differences
- Slides 11-25: PIH mechanism deep-dive
- Slides 26-40: Heat stacking identification
- Slides 41-50: Safe parameter protocols

**Workbook Exercises:**
1. Fitzpatrick risk assessment checklist
2. Inflammation-first protocol templates
3. Heat stacking audit tool
4. Safe parameter quick-reference

**Scripts:**
- "Your skin type requires an inflammation-first approach..."
- "Heat stacking is a risk we actively manage..."
- "This protocol prioritizes safety while delivering results..."

**Role Play Drills:**
1. Client requesting aggressive treatment on Fitzpatrick V skin
2. Explaining why their friend's protocol won't work for them
3. Managing expectations for higher-risk skin types

**Certification Assessment:**
- Fitzpatrick scenario quiz (20 scenarios)
- Risk protocol design submission

---

### Module 4.3: Case Mapping & Documentation

**Learning Objectives:**
- Build systematic case documentation
- Develop before/after photography protocols
- Create outcome tracking systems
- Build case study library for authority

**Teaching Framework:**
1. Documentation hierarchy
2. Photography standards
3. Outcome metric selection
4. Case study architecture

**Slide Deck Structure (40 slides):**
- Slides 1-10: Documentation as professional asset
- Slides 11-25: Photography standards and setup
- Slides 26-35: Outcome tracking systems
- Slides 36-40: Case study development

**Workbook Exercises:**
1. Documentation template design
2. Photography setup guide
3. Outcome metric selection worksheet
4. Case study template

**Certification Assessment:**
- Documentation quality review
- Sample case study submission

---

## LEVEL 5 — REVENUE & SCALABILITY SYSTEMS

### Module 5.1: Premium Service Menu Architecture

**Learning Objectives:**
- Structure service menus for value perception
- Design tiered offerings that guide optimal choice
- Build package architecture for commitment
- Develop add-on integration

**Teaching Framework:**
1. Value perception psychology
2. Tiered offering architecture
3. Package design for commitment
4. Add-on integration without pressure

**Slide Deck Structure (45 slides):**
- Slides 1-10: The psychology of premium pricing
- Slides 11-25: Tiered menu architecture
- Slides 26-40: Package design strategies
- Slides 41-45: Add-on integration

**Workbook Exercises:**
1. Service menu audit and redesign
2. Tiered offering template
3. Package architecture worksheet
4. Add-on script library

**Scripts:**
- "Our service tiers are designed around [specific outcomes]..."
- "Most clients who share your goals select [tier] because..."
- "There's one addition I'd recommend for your specific situation..."

**Role Play Drills:**
1. Presenting menu to price-sensitive client
2. Guiding client to optimal tier
3. Introducing add-on without pressure

**Certification Assessment:**
- Service menu submission
- Menu presentation simulation

---

### Module 5.2: Retail Integration Through Education

**Learning Objectives:**
- Build retail recommendations that feel like education
- Develop home care protocol confidence
- Create retail conversation frameworks
- Design retail systems that serve outcomes

**Teaching Framework:**
1. Education-first retail philosophy
2. Home care protocol architecture
3. Retail conversation frameworks
4. Outcome-based retail systems

**Slide Deck Structure (40 slides):**
- Slides 1-10: Why retail fails (and how to fix it)
- Slides 11-25: Education-first recommendation
- Slides 26-35: Home care protocol design
- Slides 36-40: Retail system integration

**Workbook Exercises:**
1. Retail conversation script library
2. Home care protocol templates
3. Product knowledge assessment
4. Retail system design

**Scripts:**
- "Your in-office treatment will be supported by this home protocol..."
- "This ingredient at home continues what we started today..."
- "Without the home component, we're managing rather than correcting..."

**Role Play Drills:**
1. Client says "I'll think about the products"
2. Client wants to buy products elsewhere
3. Client overwhelmed by product recommendations

**Certification Assessment:**
- Retail conversation simulation
- Home care protocol design

---

### Module 5.3: Referral & Retention Systems

**Learning Objectives:**
- Build referral systems through outcome excellence
- Develop retention protocols that reduce churn
- Create client loyalty through education
- Design systematic follow-up architecture

**Teaching Framework:**
1. Referral psychology
2. Retention metric optimization
3. Follow-up system design
4. Loyalty through education

**Slide Deck Structure (35 slides):**
- Slides 1-10: Why clients leave (and how to prevent it)
- Slides 11-25: Referral system architecture
- Slides 26-35: Follow-up system design

**Workbook Exercises:**
1. Referral request script library
2. Follow-up system template
3. Retention metric tracking
4. Client journey mapping

**Scripts:**
- "I'm glad you're seeing results. Who else do you know who might benefit?"
- "I want to check in on how your protocol is working..."
- "Based on your progress, here's what I recommend for next steps..."

**Certification Assessment:**
- Referral system design submission
- Follow-up protocol evaluation

---

## LEVEL 6 — EDUCATOR AUTHORITY & HIGH-TICKET SALES

### Module 6.1: Objection Dismantling Language

**Learning Objectives:**
- Master response frameworks for common objections
- Develop reframing techniques
- Build confidence in difficult conversations
- Create objection anticipation protocols

**Teaching Framework:**
1. Objection category mapping
2. Response framework architecture
3. Reframing technique library
4. Anticipation and prevention

**Slide Deck Structure (50 slides):**
- Slides 1-10: Objection psychology
- Slides 11-25: Price objection responses
- Slides 26-40: Timing objection responses
- Slides 41-50: Skepticism objection responses

**Workbook Exercises:**
1. Personal objection log (document your top 10)
2. Response script library (30 objections)
3. Reframing practice scenarios
4. Anticipation protocol development

**Scripts:**
- "I understand the investment consideration. Let me explain what this includes..."
- "Timing is always a consideration. What would need to change for this to be the right time?"
- "Skepticism is healthy. Let me share what I'd want to know if I were in your position..."

**Role Play Drills:**
1. Price objection handling
2. Timing objection handling
3. Skepticism objection handling

**Certification Assessment:**
- Objection response simulation
- Script quality evaluation

---

### Module 6.2: Conversion Psychology

**Learning Objectives:**
- Understand decision-making psychology
- Build commitment escalation frameworks
- Develop urgency without manipulation
- Create decision-support systems

**Teaching Framework:**
1. Decision psychology fundamentals
2. Commitment escalation architecture
3. Authentic urgency creation
4. Decision-support design

**Slide Deck Structure (45 slides):**
- Slides 1-10: How clients actually decide
- Slides 11-25: Commitment escalation
- Slides 26-40: Authentic urgency
- Slides 41-45: Decision support systems

**Workbook Exercises:**
1. Client decision journey map
2. Commitment escalation worksheet
3. Authentic urgency inventory
4. Decision-support tool design

**Scripts:**
- "The next step is [specific action]. Does that feel right to you?"
- "My case review availability is [specific limitation]. Here's what that means for timing..."
- "I'm not interested in you making a decision today unless you're fully confident..."

**Role Play Drills:**
1. Guiding client to commitment
2. Creating authentic urgency
3. Supporting client decision-making

**Certification Assessment:**
- Conversion conversation simulation
- Psychology application evaluation

---

### Module 6.3: Authority Positioning & Personal Brand

**Learning Objectives:**
- Develop personal authority positioning
- Build educator-level reputation
- Create content that demonstrates expertise
- Design authority-building systems

**Teaching Framework:**
1. Authority positioning fundamentals
2. Content architecture for expertise demonstration
3. Reputation building systems
4. Long-term authority development

**Slide Deck Structure (40 slides):**
- Slides 1-10: What authority actually means
- Slides 11-25: Content that builds authority
- Slides 26-35: Reputation systems
- Slides 36-40: Long-term development

**Workbook Exercises:**
1. Personal authority positioning statement
2. Content calendar template
3. Expertise demonstration inventory
4. Authority development plan

**Certification Assessment:**
- Authority positioning submission
- Content sample evaluation

---

## CERTIFICATION ASSESSMENT FRAMEWORK

### Written Examination (200 Questions)

**Section A — Structural Skin Science (50 questions)**
- Corneocyte function and barrier mechanics
- Dermal matrix and fibroblast signaling
- Inflammatory cascades
- Fitzpatrick structural differences

**Section B — Ingredient Intelligence (50 questions)**
- Mechanism mapping
- Contraindication awareness
- pH and sequencing
- Comparison frameworks

**Section C — Consultation Architecture (40 questions)**
- Layered questioning
- Emotional intelligence
- Pathway presentation
- Objection handling

**Section D — Treatment Structuring (30 questions)**
- Protocol design
- Risk management
- Case mapping

**Section E — Revenue Systems (30 questions)**
- Service architecture
- Retail integration
- Retention systems

**Passing Score:** 85% overall, no section below 80%

---

### Practical Assessments

**1. Consultation Simulation (Live)**
- 30-minute intake with evaluator playing client
- Assessed on: questioning, presence, pathway presentation
- Minimum score: 85%

**2. Ingredient Defense (Written + Oral)**
- Random selection of 10 ingredients
- Must explain mechanism, contraindications, sequencing
- Minimum score: 85%

**3. Case Defense Presentation**
- Submit full case documentation
- 15-minute presentation with Q&A
- Assessed on: protocol logic, risk management, outcome prediction

---

### Recertification Requirements

- Biennial continuing education (20 hours)
- Case study submission (2 per year)
- Peer review participation
- Knowledge currency assessment

---

## DELIVERY LOGISTICS

**Cohort Schedule:**
- New cohorts begin first Monday of each month
- 12-week intensive track
- 6-month standard track
- Maximum 25 students per cohort

**Live Components:**
- Weekly Q&A sessions (Tuesdays, 7pm EST)
- Case review sessions (bi-weekly)
- Final defense presentations (scheduled individually)

**Self-Paced Components:**
- All modules accessible 24/7
- Workbook exercises submitted through portal
- Peer discussion forums

**Support:**
- Instructor office hours (Thursdays)
- Peer study groups (facilitated)
- Certification concierge for questions

---

## INSTRUCTOR QUALIFICATIONS

**Lead Instructor:** Conrad St. Denis
- Former National Educator, Visage Cosmetics Ltd. (2004-2022)
- Aveda Academy Certification (2012-2013)
- Senior Executive Artist & Territory Revenue Leadership
- Franchisee Performance Optimization Specialist

**Guest Instructors:**
- Dermatology advisors (clinical consultation)
- Cosmetic chemistry experts (ingredient deep-dives)
- Business strategy consultants (revenue systems)

---

*Ambitiously Institute — Executive Beauty Architecture™*
*Curriculum Version 1.0 | © 2024*
