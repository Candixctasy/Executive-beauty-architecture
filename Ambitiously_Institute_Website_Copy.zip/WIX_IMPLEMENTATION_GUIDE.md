# WIX IMPLEMENTATION GUIDE
## Ambitiously Institute — Executive Beauty Architecture
### Complete Copy-Paste Setup Instructions

---

## BEFORE YOU START

**What You Need:**
- Wix account (free or premium)
- Wix Editor access
- 2-3 hours for setup

**Recommended Wix Plan:**
- **Business Basic** ($17/mo) — For accepting payments
- **Business Unlimited** ($25/mo) — For subscriptions and more storage

---

## STEP 1: CREATE YOUR SITE

1. Go to **wix.com** and sign in
2. Click **"Create New Site"**
3. Select **"Blank Canvas"** (start from scratch)
4. Name your site: **"Ambitiously Institute"**

---

## STEP 2: SET UP GLOBAL DESIGN

### Colors (Site Design → Colors)

| Color Name | Hex Code | Usage |
|------------|----------|-------|
| Ink (Primary Dark) | `#0e0c0b` | Backgrounds, text |
| Charcoal | `#1a1714` | Section backgrounds |
| Warm Dark | `#231f1b` | Card backgrounds |
| Ivory | `#f5f0e8` | Primary text |
| Cream | `#ede7d9` | Secondary text |
| Gold | `#b8933f` | Accents, CTAs |
| Gold Light | `#d4aa5a` | Hover states |
| Text Muted | `#7a6e62` | Subtle text |

**How to set:**
1. Click **Site Design** (top left)
2. Click **Colors**
3. Click **Edit Palette**
4. Replace colors with hex codes above

---

### Fonts (Site Design → Text)

**Heading Font:** Playfair Display (or Cormorant Garamond)
**Body Font:** DM Sans

**How to set:**
1. Click **Site Design** → **Text**
2. For **Heading 1**: Change to Playfair Display, 300 weight
3. For **Paragraph**: Change to DM Sans, 400 weight

---

## STEP 3: INSTALL REQUIRED APPS

1. Click **Apps** (left sidebar)
2. Click **App Market**
3. Search and install:

**Required Apps:**
- ✅ **Wix Members Area** — For gated content
- ✅ **Wix Pricing Plans** — For program tiers
- ✅ **Wix Online Programs** — For course delivery
- ✅ **Wix Forms** — For applications
- ✅ **Wix Chat** — For visitor engagement

**Optional Apps:**
- Wix Blog — For authority content
- Wix Bookings — For consultation scheduling
- Wix Analytics — For tracking

---

## STEP 4: BUILD EACH PAGE

---

### PAGE 1: HOME PAGE

**Page Settings:**
- Page Name: Home
- SEO Title: Executive Beauty Architect Certification | Ambitiously Institute
- SEO Description: Clinical intelligence. Structural thinking. Elevated communication. The certification program for beauty professionals ready to architect outcomes.

---

#### SECTION 1: HERO

**Section Type:** Strip (full width)
**Background:** Color → Ink `#0e0c0b`
**Height:** 100vh (full screen)

**Elements to Add:**

**1. Eyebrow Text**
```
Text: AMBITIOUSLY INSTITUTE — PROFESSIONAL CERTIFICATION PROGRAM
Font: DM Sans, 11px, uppercase, letter-spacing 3px
Color: Gold #b8933f
Position: Top left, 120px from top
```

**2. Headline**
```
Text: Executive Beauty Architect™ Certification
Font: Playfair Display, 48px (desktop), 32px (mobile)
Color: Ivory #f5f0e8
Weight: 300
Position: Below eyebrow, 24px spacing
```

**3. Subheadline**
```
Text: Clinical intelligence. Structural thinking. Elevated communication.
Font: DM Sans, 18px
Color: Cream #ede7d9
Position: Below headline, 20px spacing
Max width: 500px
```

**4. Body Text**
```
Text: The beauty industry trained you to sell. We train you to architect outcomes. This is not a course. This is a certification in structured reasoning, ingredient mastery, and consultation authority.
Font: DM Sans, 16px, line-height 1.7
Color: Text Muted #7a6e62
Position: Below subheadline, 28px spacing
Max width: 520px
```

**5. Primary CTA Button**
```
Text: BEGIN CERTIFICATION PATH
Background: Gold #b8933f
Text Color: Ink #0e0c0b
Font: DM Sans, 12px, uppercase, letter-spacing 2px
Padding: 16px 40px
Border radius: 0
Hover: Background changes to Gold Light #d4aa5a
Link: /certification (create this page next)
Position: Below body text, 32px spacing
```

**6. Secondary CTA Button**
```
Text: DOWNLOAD PROGRAM SYLLABUS
Background: Transparent
Border: 1px solid rgba(245,240,232,0.25)
Text Color: Cream #ede7d9
Font: DM Sans, 12px, uppercase, letter-spacing 2px
Padding: 16px 40px
Border radius: 0
Hover: Border color changes to Gold #b8933f
Link: Upload your syllabus PDF to Media Manager, link to file
Position: Right of primary CTA, 16px spacing
```

**7. Authority Marker (Bottom Right)**
```
Text: Founding Cohort Enrollment — Limited Case Review Availability
Font: DM Sans, 11px, uppercase, letter-spacing 2px
Color: Gold #b8933f
Position: Bottom right of hero
```

---

#### SECTION 2: THE PROBLEM

**Section Type:** Strip
**Background:** Charcoal `#1a1714`
**Padding:** 120px top, 120px bottom

**Elements:**

**Section Label**
```
Text: THE CURRENT STATE
Font: DM Sans, 11px, uppercase, letter-spacing 3px
Color: Gold #b8933f
```

**Headline**
```
Text: The Industry Trained You to Sell.
Font: Playfair Display, 42px
Color: Ivory #f5f0e8
```

**Body Copy**
```
Text: 
You were taught scripts.
Retail goals.
Objection handling.

But educated clients don't want pressure.
They want clarity.

When professionals rely on sales tactics, trust erodes.
When professionals rely on structural reasoning, authority increases.

The gap between where you are and where you could be is not more products.
It's architectural thinking.

Font: DM Sans, 16px, line-height 1.8
Color: Text Muted #7a6e62
Max width: 600px
```

---

#### SECTION 3: THE SHIFT (3 COLUMNS)

**Section Type:** Strip
**Background:** Warm Dark `#231f1b`
**Padding:** 120px top, 120px bottom

**Layout:** 3 columns (equal width)

**Column 1: Structural Skin Science**
```
Number: 01
Font: Playfair Display, 14px, letter-spacing 3px
Color: Gold #b8933f

Title: Structural Skin Science
Font: Playfair Display, 28px
Color: Ivory #f5f0e8

Body: Understand the epidermis as a regulatory system, not a surface. Master barrier function, inflammatory cascades, and cellular signaling. Speak from mechanism, not memorization.
Font: DM Sans, 15px, line-height 1.7
Color: Text Muted #7a6e62
```

**Column 2: Ingredient Intelligence**
```
Number: 02
Font: Playfair Display, 14px, letter-spacing 3px
Color: Gold #b8933f

Title: Ingredient Intelligence
Font: Playfair Display, 28px
Color: Ivory #f5f0e8

Body: Move beyond "this is good for acne." Learn molecular pathways, contraindication matrices, and layering architecture. Translate chemistry into client confidence.
Font: DM Sans, 15px, line-height 1.7
Color: Text Muted #7a6e62
```

**Column 3: Consultation Architecture**
```
Number: 03
Font: Playfair Display, 14px, letter-spacing 3px
Color: Gold #b8933f

Title: Consultation Architecture
Font: Playfair Display, 28px
Color: Ivory #f5f0e8

Body: Replace scripts with structured inquiry. Design conversations that extract information, build trust, and present solutions without pressure. Close through education, not manipulation.
Font: DM Sans, 15px, line-height 1.7
Color: Text Muted #7a6e62
```

---

#### SECTION 4: WHO THIS IS FOR

**Section Type:** Strip
**Background:** Ink `#0e0c0b`
**Padding:** 120px top, 120px bottom

**Headline**
```
Text: This Certification Is Designed For:
Font: Playfair Display, 42px
Color: Ivory #f5f0e8
```

**Bullet List (Add as text with checkmarks)**
```
✓ Medical estheticians seeking clinical communication elevation
✓ Advanced facialists ready for educator-level authority
✓ Clinic owners building differentiated positioning
✓ Brand trainers developing proprietary frameworks
✓ Professionals transitioning from service provider to authority figure
✓ Operators ready for executive-level communication

Font: DM Sans, 16px, line-height 2
Color: Cream #ede7d9
```

**Exclusion Statement**
```
Text: This is not for beginners. Foundational knowledge of skin anatomy and professional practice is required.
Font: DM Sans, 14px, italic
Color: Text Muted #7a6e62
Margin top: 40px
```

---

#### SECTION 5: PROGRAM STRUCTURE

**Section Type:** Strip
**Background:** Charcoal `#1a1714`
**Padding:** 120px top, 120px bottom

**Headline**
```
Text: Six Tiers. One Transformation.
Font: Playfair Display, 42px
Color: Ivory #f5f0e8
```

**Add Accordion Element (from Wix elements)**

**Accordion Item 1:**
```
Title: Tier I — Delivery & Language
Content: Master the vocabulary of clinical authority. Learn to communicate structural concepts with precision. Eliminate filler language and uncertain phrasing.
```

**Accordion Item 2:**
```
Title: Tier II — Consultation Architecture
Content: Build systematic intake protocols. Design layered questioning frameworks. Extract critical information while building psychological safety.
```

**Accordion Item 3:**
```
Title: Tier III — Ingredient & Skin Science Translation
Content: Decode molecular mechanisms. Map contraindications. Build layering protocols that maximize efficacy while minimizing risk.
```

**Accordion Item 4:**
```
Title: Tier IV — Treatment Structuring
Content: Architect 30-60-90 day protocols. Stage corrective interventions. Design maintenance systems that sustain results.
```

**Accordion Item 5:**
```
Title: Tier V — Revenue & Scalability Systems
Content: Structure premium service menus. Design retail integration that feels like education. Build referral systems through outcome excellence.
```

**Accordion Item 6:**
```
Title: Tier VI — Educator Authority & High-Ticket Sales
Content: Develop executive presence. Master objection dismantling. Position yourself as the authority clients seek, not the service they compare.
```

---

#### SECTION 6: CERTIFICATION STANDARDS

**Section Type:** Strip
**Background:** Warm Dark `#231f1b`
**Padding:** 120px top, 120px bottom

**Headline**
```
Text: Certification Is Earned.
Font: Playfair Display, 42px
Color: Ivory #f5f0e8
```

**Subheadline**
```
Text: This is where we separate from content courses.
Font: DM Sans, 16px
Color: Text Muted #7a6e62
```

**Requirements List**
```
• 200-question written examination (minimum 85%)
• Ingredient intelligence assessment (no section below 80%)
• Consultation simulation with live evaluation
• Case defense presentation with protocol rationale
• Final review by certification board

Font: DM Sans, 16px, line-height 2
Color: Cream #ede7d9
```

**Credential Info**
```
Text: Upon successful completion, graduates receive the Executive Beauty Architect™ (EBA™) designation and digital certification credential.

Continuing Education: Active certification requires biennial recertification to ensure continued competency and knowledge currency.

Font: DM Sans, 15px, line-height 1.7
Color: Text Muted #7a6e62
Margin top: 32px
```

---

#### SECTION 7: INVESTMENT

**Section Type:** Strip
**Background:** Ink `#0e0c0b`
**Padding:** 120px top, 120px bottom

**Headline**
```
Text: Investment Tiers
Font: Playfair Display, 42px
Color: Ivory #f5f0e8
```

**Anchor Statement**
```
Text: One incorrect corrective protocol can cost you client trust permanently. One elevated consultation can increase client lifetime value by 3-5x.
Font: DM Sans, 16px, italic
Color: Text Muted #7a6e62
Max width: 600px
```

**Add 3 Pricing Cards (using Wix Pricing Plans or custom design)**

**Card 1: Professional Track**
```
Tier Label: TIER I–II
Name: Professional Track
Price: $1,497 CAD
Payment Plan: or 3 × $550 CAD
Features:
- Structural Foundations
- Ingredient Intelligence
- Layering Fundamentals
- Digital Workbook

CTA: ENROLL NOW
```

**Card 2: Executive Track**
```
Tier Label: TIER I–IV
Name: Executive Track
Price: $2,997 CAD
Payment Plan: or 4 × $850 CAD
Features:
- Full Structural Mastery
- Ingredient Architecture
- Consultation Design
- Case Strategy
- Everything in Professional

CTA: ENROLL NOW
```

**Card 3: Full Certification (Featured)**
```
Tier Label: FULL CERTIFICATION
Name: Executive Beauty Architect™
Badge: MOST POPULAR
Price: $4,500 CAD
Founding Price: $2,997 CAD
Payment Plan: or 6 × $825 CAD
Features:
- All Six Tiers
- Full Examination
- Case Defense Review
- EBA™ Credential
- Digital Certificate
- Lifetime Access

CTA: ENROLL NOW — FOUNDING COHORT
```

**Scarcity Note**
```
Text: Limited case defense review windows per quarter. Founding cohort pricing will not return.
Font: DM Sans, 12px, uppercase, letter-spacing 2px
Color: Gold #b8933f
```

---

#### SECTION 8: FINAL CTA

**Section Type:** Strip
**Background:** Charcoal `#1a1714`
**Padding:** 140px top, 140px bottom
**Text Align:** Center

**Eyebrow**
```
Text: THE DECISION
Font: DM Sans, 11px, uppercase, letter-spacing 3px
Color: Gold #b8933f
```

**Headline**
```
Text: Stop Selling. Start Architecting.
Font: Playfair Display, 52px
Color: Ivory #f5f0e8
```

**Body**
```
Text: The beauty industry will continue to change. Products will evolve. Trends will shift. Client expectations will rise.

What remains constant is the need for professionals who can think structurally, communicate clinically, and architect outcomes with confidence.

That professional can be you.

Font: DM Sans, 16px, line-height 1.8
Color: Text Muted #7a6e62
Max width: 600px
Center aligned
```

**Primary CTA**
```
Text: ENROLL IN EXECUTIVE BEAUTY ARCHITECT™ CERTIFICATION
Background: Gold #b8933f
Text Color: Ink #0e0c0b
Font: DM Sans, 12px, uppercase, letter-spacing 2px
Padding: 18px 48px
Link: /certification
```

**Secondary CTA**
```
Text: SCHEDULE A CERTIFICATION CONSULTATION
Background: Transparent
Border: 1px solid rgba(245,240,232,0.25)
Text Color: Cream #ede7d9
Font: DM Sans, 12px, uppercase, letter-spacing 2px
Padding: 18px 48px
Link: /consultation (or Wix Bookings)
```

---

#### SECTION 9: FOOTER

**Section Type:** Strip
**Background:** Ink `#0e0c0b`
**Padding:** 60px top, 40px bottom

**3-Column Layout:**

**Column 1: Brand**
```
Logo Text: AMBITIOUSLY <span style="color:#b8933f">INSTITUTE</span>
Font: Playfair Display, 18px, uppercase, letter-spacing 2px
Color: Ivory #f5f0e8

Tagline: Executive Beauty Architecture™
Font: DM Sans, 12px
Color: Text Muted #7a6e62
```

**Column 2: Navigation**
```
Links:
- Certification
- Curriculum
- About
- Contact

Font: DM Sans, 14px
Color: Text Muted #7a6e62
Hover: Cream #ede7d9
```

**Column 3: Legal**
```
Links:
- Terms of Certification
- Privacy Policy
- Cookie Policy

Font: DM Sans, 14px
Color: Text Muted #7a6e62
Hover: Cream #ede7d9
```

**Copyright**
```
Text: © 2024 Ambitiously Institute. All Rights Reserved.
Font: DM Sans, 12px
Color: rgba(122,110,98,0.5)
```

---

### PAGE 2: CERTIFICATION PAGE

**Page Settings:**
- Page Name: Certification
- URL: /certification
- SEO Title: Executive Beauty Architect Certification Program | Ambitiously Institute

**Content:** Use the full curriculum content from the document I provided earlier, organized in sections similar to the home page.

---

### PAGE 3: ABOUT PAGE

**Page Settings:**
- Page Name: About
- URL: /about

**Content:**
```
Headline: About Ambitiously Institute

Body: 
Ambitiously Institute is the authority in structured beauty education. Founded by Conrad St. Denis, former National Educator at Visage Cosmetics Ltd., we train beauty professionals to think structurally, communicate clinically, and architect outcomes with authority.

Our methodology — Executive Beauty Architecture™ — replaces sales scripts with scientific reasoning, transforming practitioners into educators and service providers into authority figures.

Founder Credentials:
- National Educator, Visage Cosmetics Ltd. (2004-2022)
- Senior Executive Artist & Territory Revenue Leadership
- Aveda Academy Certification (2012-2013)
- Franchisee Performance Optimization Specialist

Mission:
To establish the definitive standard for professional excellence in beauty — the credential that separates practitioners from architects.
```

---

### PAGE 4: TERMS OF CERTIFICATION

**Page Settings:**
- Page Name: Terms of Certification
- URL: /terms

**Content:** Use the full legal terms from the PDF document I read earlier.

---

## STEP 5: SET UP PRICING PLANS

1. Go to **Pricing Plans** app
2. Create 3 plans:

**Plan 1: Professional Track**
- Price: $1,497
- Payment plan: 3 payments of $550
- Description: Modules 1-2 | Structural Foundations + Ingredient Intelligence

**Plan 2: Executive Track**
- Price: $2,997
- Payment plan: 4 payments of $850
- Description: Modules 1-4 | Full Structural + Consultation Mastery

**Plan 3: Full Certification**
- Price: $4,500 (show founding price $2,997)
- Payment plan: 6 payments of $825
- Description: All Tiers + Exams + Case Defense + EBA™ Credential

---

## STEP 6: SET UP ONLINE PROGRAMS

1. Go to **Online Programs** app
2. Create program: "Executive Beauty Architect Certification"
3. Add modules from curriculum document
4. Upload lessons
5. Set up quizzes and assessments

---

## STEP 7: CONNECT EVERYTHING

1. Link CTA buttons to Pricing Plans
2. Link "Download Syllabus" to PDF in Media Manager
3. Set up form submissions to go to your email
4. Connect domain (if you have one)

---

## STEP 8: PUBLISH

1. Click **Publish** (top right)
2. Choose domain (free Wix subdomain or custom)
3. Your site is LIVE!

---

## ADDITIONAL RESOURCES

### Images to Source:
- Professional headshot of Conrad St. Denis
- Clean, clinical beauty imagery (no spa fluff)
- Abstract architectural elements
- White marble textures

**Recommended Stock Sites:**
- Unsplash (free)
- Pexels (free)
- Stocksy (premium, editorial)

### Copy Documents:
All copy is in the documents I created. Copy-paste directly from:
- `1_Ambitiously_Institute_Website_Copy.md`
- `2_Executive_Beauty_Architect_Certification_Curriculum.md`

---

## NEED HELP?

**Wix Support:** support.wix.com
**Wix Tutorials:** wix.com/learn

---

*This guide provides everything needed to build your Ambitiously Institute website in Wix. Follow step-by-step, copy-paste the content, and you'll have a live, professional site.*
