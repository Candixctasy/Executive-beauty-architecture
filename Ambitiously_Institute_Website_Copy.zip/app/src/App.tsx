import { useState, useEffect } from 'react';
import { ChevronDown, Check, Menu, X } from 'lucide-react';

const STRIPE_CHECKOUT_URL = 'https://buy.stripe.com/5kQ00l0JAeLS4dgaUAfUQ02';

function App() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [openAccordion, setOpenAccordion] = useState<number | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setMobileMenuOpen(false);
  };

  const tiers = [
    {
      number: '01',
      title: 'Structural Skin Science',
      description: 'Understand the epidermis as a regulatory system, not a surface. Master barrier function, inflammatory cascades, and cellular signaling. Speak from mechanism, not memorization.'
    },
    {
      number: '02',
      title: 'Ingredient Intelligence',
      description: 'Move beyond "this is good for acne." Learn molecular pathways, contraindication matrices, and layering architecture. Translate chemistry into client confidence.'
    },
    {
      number: '03',
      title: 'Consultation Architecture',
      description: 'Replace scripts with structured inquiry. Design conversations that extract information, build trust, and present solutions without pressure. Close through education, not manipulation.'
    }
  ];

  const programTiers = [
    {
      title: 'Tier I — Delivery & Language',
      content: 'Master the vocabulary of clinical authority. Learn to communicate structural concepts with precision. Eliminate filler language and uncertain phrasing.'
    },
    {
      title: 'Tier II — Consultation Architecture',
      content: 'Build systematic intake protocols. Design layered questioning frameworks. Extract critical information while building psychological safety.'
    },
    {
      title: 'Tier III — Ingredient & Skin Science Translation',
      content: 'Decode molecular mechanisms. Map contraindications. Build layering protocols that maximize efficacy while minimizing risk.'
    },
    {
      title: 'Tier IV — Treatment Structuring',
      content: 'Architect 30-60-90 day protocols. Stage corrective interventions. Design maintenance systems that sustain results.'
    },
    {
      title: 'Tier V — Revenue & Scalability Systems',
      content: 'Structure premium service menus. Design retail integration that feels like education. Build referral systems through outcome excellence.'
    },
    {
      title: 'Tier VI — Educator Authority & High-Ticket Sales',
      content: 'Develop executive presence. Master objection dismantling. Position yourself as the authority clients seek, not the service they compare.'
    }
  ];

  const whoIsThisFor = [
    'Medical estheticians seeking clinical communication elevation',
    'Advanced facialists ready for educator-level authority',
    'Clinic owners building differentiated positioning',
    'Brand trainers developing proprietary frameworks',
    'Professionals transitioning from service provider to authority figure',
    'Operators ready for executive-level communication'
  ];

  const certificationRequirements = [
    '200-question written examination (minimum 85%)',
    'Ingredient intelligence assessment (no section below 80%)',
    'Consultation simulation with live evaluation',
    'Case defense presentation with protocol rationale',
    'Final review by certification board'
  ];

  return (
    <div className="min-h-screen bg-[#0e0c0b]">
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-400 ${isScrolled ? 'nav-scrolled py-4' : 'py-6'}`}>
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between">
          <div className="font-display text-lg uppercase tracking-widest text-[#f5f0e8]">
            Ambitiously <span className="text-[#b8933f]">Institute</span>
          </div>
          
          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            <button onClick={() => scrollToSection('problem')} className="text-xs uppercase tracking-widest text-[#ede7d9] opacity-75 hover:opacity-100 hover:text-[#d4aa5a] transition-colors">
              About
            </button>
            <button onClick={() => scrollToSection('program')} className="text-xs uppercase tracking-widest text-[#ede7d9] opacity-75 hover:opacity-100 hover:text-[#d4aa5a] transition-colors">
              Curriculum
            </button>
            <button onClick={() => scrollToSection('investment')} className="text-xs uppercase tracking-widest text-[#ede7d9] opacity-75 hover:opacity-100 hover:text-[#d4aa5a] transition-colors">
              Investment
            </button>
            <a href={STRIPE_CHECKOUT_URL} target="_blank" rel="noopener noreferrer" className="text-xs uppercase tracking-widest px-6 py-2 border border-[#b8933f] text-[#b8933f] hover:bg-[#b8933f] hover:text-[#0e0c0b] transition-all">
              Enroll
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-[#f5f0e8]"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden absolute top-full left-0 right-0 bg-[#1a1714] border-t border-[#b8933f]/20 py-6 px-6">
            <div className="flex flex-col gap-4">
              <button onClick={() => scrollToSection('problem')} className="text-left text-sm uppercase tracking-widest text-[#ede7d9]">
                About
              </button>
              <button onClick={() => scrollToSection('program')} className="text-left text-sm uppercase tracking-widest text-[#ede7d9]">
                Curriculum
              </button>
              <button onClick={() => scrollToSection('investment')} className="text-left text-sm uppercase tracking-widest text-[#ede7d9]">
                Investment
              </button>
              <a href={STRIPE_CHECKOUT_URL} target="_blank" rel="noopener noreferrer" className="text-left text-sm uppercase tracking-widest text-[#b8933f]">
                Enroll Now
              </a>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="min-h-screen flex items-center relative overflow-hidden pt-24 pb-16">
        {/* Background decorative circles */}
        <div className="absolute right-[-180px] top-1/2 -translate-y-1/2 w-[600px] h-[600px] border border-[#b8933f]/12 rounded-full pointer-events-none" />
        <div className="absolute right-[-80px] top-1/2 -translate-y-1/2 w-[400px] h-[400px] border border-[#b8933f]/18 rounded-full pointer-events-none" />
        
        <div className="max-w-6xl mx-auto px-6 relative z-10 w-full">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <div className="inline-block text-[11px] uppercase tracking-[3px] text-[#b8933f] mb-6 pb-4 border-b border-[#b8933f]/35">
                Ambitiously Institute — Professional Certification Program
              </div>
              
              <h1 className="font-display text-5xl md:text-6xl lg:text-7xl font-light text-[#f5f0e8] leading-[1.05] mb-6">
                Executive Beauty Architect™ <em className="text-[#d4aa5a] not-italic">Certification</em>
              </h1>
              
              <p className="text-lg text-[#ede7d9] mb-6">
                Clinical intelligence. Structural thinking. Elevated communication.
              </p>
              
              <p className="text-base text-[#7a6e62] leading-relaxed max-w-lg mb-10">
                The beauty industry trained you to sell. We train you to architect outcomes. This is not a course. This is a certification in structured reasoning, ingredient mastery, and consultation authority.
              </p>
              
              <div className="flex flex-wrap gap-4">
                <a href={STRIPE_CHECKOUT_URL} target="_blank" rel="noopener noreferrer" className="btn-primary">
                  Begin Certification Path
                </a>
                <button onClick={() => scrollToSection('program')} className="btn-secondary">
                  View Program Syllabus
                </button>
              </div>
            </div>
            
            <div className="hidden lg:block">
              <div className="bg-[#231f1b]/70 border border-[#b8933f]/35 p-10 relative">
                <div className="gold-line absolute top-0 left-0" />
                
                <div className="mb-8">
                  <div className="font-display text-5xl font-light text-[#d4aa5a] mb-2">6</div>
                  <div className="text-xs uppercase tracking-[3px] text-[#7a6e62]">Certification Tiers</div>
                </div>
                
                <div className="w-full h-px bg-[#b8933f]/35 mb-8" />
                
                <div className="mb-8">
                  <div className="font-display text-5xl font-light text-[#d4aa5a] mb-2">200</div>
                  <div className="text-xs uppercase tracking-[3px] text-[#7a6e62]">Question Examination</div>
                </div>
                
                <div className="w-full h-px bg-[#b8933f]/35 mb-8" />
                
                <div>
                  <div className="font-display text-5xl font-light text-[#d4aa5a] mb-2">EBA™</div>
                  <div className="text-xs uppercase tracking-[3px] text-[#7a6e62]">Professional Credential</div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="absolute bottom-8 right-6 text-[11px] uppercase tracking-[2px] text-[#b8933f]">
            Founding Cohort Enrollment — Limited Case Review Availability
          </div>
        </div>
      </section>

      {/* The Problem Section */}
      <section id="problem" className="py-32 bg-[#1a1714]">
        <div className="max-w-6xl mx-auto px-6">
          <div className="section-divider max-w-xl">
            <div className="section-divider-dot" />
          </div>
          
          <div className="text-[11px] uppercase tracking-[3px] text-[#b8933f] mb-4">
            The Current State
          </div>
          
          <h2 className="font-display text-4xl md:text-5xl font-light text-[#f5f0e8] mb-10">
            The Industry Trained You to <em className="text-[#d4aa5a] not-italic">Sell.</em>
          </h2>
          
          <div className="max-w-2xl">
            <p className="text-lg text-[#7a6e62] leading-relaxed mb-6">
              You were taught scripts.<br />
              Retail goals.<br />
              Objection handling.
            </p>
            
            <p className="text-lg text-[#7a6e62] leading-relaxed mb-6">
              But educated clients don't want pressure.<br />
              They want clarity.
            </p>
            
            <p className="text-lg text-[#7a6e62] leading-relaxed mb-6">
              When professionals rely on sales tactics, trust erodes.<br />
              When professionals rely on structural reasoning, authority increases.
            </p>
            
            <p className="text-lg text-[#ede7d9] leading-relaxed">
              The gap between where you are and where you could be is not more products.<br />
              It's <span className="text-[#b8933f]">architectural thinking.</span>
            </p>
          </div>
        </div>
      </section>

      {/* The Shift Section - 3 Pillars */}
      <section id="shift" className="py-32 bg-[#231f1b] relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#1a1714]/40 pointer-events-none" />
        
        <div className="max-w-6xl mx-auto px-6 relative z-10">
          <div className="text-center max-w-2xl mx-auto mb-20">
            <div className="text-[11px] uppercase tracking-[3px] text-[#b8933f] mb-4">
              The Methodology
            </div>
            <h2 className="font-display text-4xl md:text-5xl font-light text-[#f5f0e8]">
              Executive Beauty Architecture™ Changes the <em className="text-[#d4aa5a] not-italic">Dynamic.</em>
            </h2>
          </div>
          
          <div className="grid md:grid-cols-3 gap-px bg-[#b8933f]/10">
            {tiers.map((tier, index) => (
              <div key={index} className="pillar-card bg-[#0e0c0b]/50 border border-[#b8933f]/10 p-10 hover:bg-[#0e0c0b]/80 transition-all">
                <div className="font-display text-sm tracking-[3px] text-[#b8933f] mb-6">
                  {tier.number}
                </div>
                <h3 className="font-display text-2xl md:text-3xl font-normal text-[#f5f0e8] mb-5 leading-tight">
                  {tier.title}
                </h3>
                <p className="text-sm text-[#7a6e62] leading-relaxed">
                  {tier.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Who This Is For Section */}
      <section className="py-32 bg-[#0e0c0b]">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-start">
            <div>
              <div className="section-divider max-w-xl mb-10">
                <div className="section-divider-dot" />
              </div>
              
              <h2 className="font-display text-4xl md:text-5xl font-light text-[#f5f0e8] mb-10">
                This Certification Is Designed <em className="text-[#d4aa5a] not-italic">For:</em>
              </h2>
              
              <ul className="space-y-4">
                {whoIsThisFor.map((item, index) => (
                  <li key={index} className="flex items-start gap-4">
                    <Check className="w-5 h-5 text-[#b8933f] mt-0.5 flex-shrink-0" />
                    <span className="text-base text-[#ede7d9]">{item}</span>
                  </li>
                ))}
              </ul>
              
              <p className="text-sm text-[#7a6e62] italic mt-10">
                This is not for beginners. Foundational knowledge of skin anatomy and professional practice is required.
              </p>
            </div>
            
            <div className="bg-[#231f1b]/60 border border-[#b8933f]/35 p-10 relative">
              <div className="absolute top-0 right-0 w-0.5 h-16 bg-[#b8933f]" />
              
              <h3 className="font-display text-3xl font-normal text-[#f5f0e8] mb-6">
                The Outcome
              </h3>
              
              <p className="text-base text-[#7a6e62] leading-relaxed mb-8">
                Graduates of the Executive Beauty Architect Certification don't just improve their technical skills. They transform their professional identity.
              </p>
              
              <div className="space-y-3">
                <div className="flex items-center gap-4">
                  <div className="w-5 h-px bg-[#b8933f]" />
                  <span className="text-sm text-[#ede7d9]">From service provider → Outcome architect</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-5 h-px bg-[#b8933f]" />
                  <span className="text-sm text-[#ede7d9]">From product seller → Education-based authority</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-5 h-px bg-[#b8933f]" />
                  <span className="text-sm text-[#ede7d9]">From following scripts → Designing protocols</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Program Structure Section */}
      <section id="program" className="py-32 bg-[#1a1714]">
        <div className="max-w-6xl mx-auto px-6">
          <div className="section-divider max-w-xl mb-10">
            <div className="section-divider-dot" />
          </div>
          
          <div className="text-[11px] uppercase tracking-[3px] text-[#b8933f] mb-4">
            Program Structure
          </div>
          
          <h2 className="font-display text-4xl md:text-5xl font-light text-[#f5f0e8] mb-16">
            Six Tiers. One <em className="text-[#d4aa5a] not-italic">Transformation.</em>
          </h2>
          
          <div className="max-w-3xl space-y-4">
            {programTiers.map((tier, index) => (
              <div key={index} className="border-b border-[#b8933f]/15">
                <button
                  onClick={() => setOpenAccordion(openAccordion === index ? null : index)}
                  className="w-full py-6 flex items-center justify-between text-left group"
                >
                  <span className="font-display text-lg md:text-xl font-normal text-[#f5f0e8] group-hover:text-[#d4aa5a] transition-colors">
                    {tier.title}
                  </span>
                  <ChevronDown 
                    className={`w-6 h-6 text-[#b8933f] transition-transform duration-300 ${openAccordion === index ? 'rotate-180' : ''}`}
                  />
                </button>
                <div className={`accordion-content ${openAccordion === index ? 'open' : ''}`}>
                  <p className="pb-6 text-base text-[#7a6e62] leading-relaxed max-w-2xl">
                    {tier.content}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Certification Standards Section */}
      <section className="py-32 bg-[#231f1b]">
        <div className="max-w-6xl mx-auto px-6">
          <div className="section-divider max-w-xl mb-10">
            <div className="section-divider-dot" />
          </div>
          
          <h2 className="font-display text-4xl md:text-5xl font-light text-[#f5f0e8] mb-6">
            Certification Is <em className="text-[#d4aa5a] not-italic">Earned.</em>
          </h2>
          
          <p className="text-base text-[#7a6e62] mb-10">
            This is where we separate from content courses.
          </p>
          
          <ul className="space-y-4 max-w-2xl mb-12">
            {certificationRequirements.map((req, index) => (
              <li key={index} className="flex items-start gap-4">
                <span className="text-[#b8933f]">—</span>
                <span className="text-base text-[#ede7d9]">{req}</span>
              </li>
            ))}
          </ul>
          
          <div className="bg-[#0e0c0b]/50 border border-[#b8933f]/20 p-8 max-w-2xl">
            <p className="text-base text-[#ede7d9] leading-relaxed mb-4">
              Upon successful completion, graduates receive the <span className="text-[#b8933f]">Executive Beauty Architect™ (EBA™)</span> designation and digital certification credential.
            </p>
            <p className="text-sm text-[#7a6e62]">
              Active certification requires biennial recertification to ensure continued competency and knowledge currency.
            </p>
          </div>
        </div>
      </section>

      {/* Investment Section */}
      <section id="investment" className="py-32 bg-[#0e0c0b] relative overflow-hidden">
        {/* Background text */}
        <div className="absolute right-[-100px] top-1/2 -translate-y-1/2 font-display text-[200px] font-light text-[#b8933f]/[0.04] tracking-wider rotate-90 whitespace-nowrap pointer-events-none">
          INVEST
        </div>
        
        <div className="max-w-6xl mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <div className="section-divider max-w-xl mx-auto mb-10">
              <div className="section-divider-dot" />
            </div>
            
            <h2 className="font-display text-4xl md:text-5xl font-light text-[#f5f0e8] mb-6">
              Investment <em className="text-[#d4aa5a] not-italic">Tiers</em>
            </h2>
            
            <p className="text-base text-[#7a6e62] italic max-w-xl mx-auto">
              One incorrect corrective protocol can cost you client trust permanently. One elevated consultation can increase client lifetime value by 3-5x.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6">
            {/* Professional Track */}
            <div className="pricing-card bg-[#0e0c0b]/60 p-10">
              <div className="text-[11px] uppercase tracking-[3px] text-[#b8933f] mb-5">
                Tier I–II
              </div>
              <h3 className="font-display text-2xl font-normal text-[#f5f0e8] mb-3">
                Professional Track
              </h3>
              <div className="font-display text-5xl font-light text-[#d4aa5a] mb-2">
                $1,497
              </div>
              <div className="text-sm text-[#7a6e62] mb-8">
                or 3 × $550 CAD
              </div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start gap-3 text-sm text-[#ede7d9]">
                  <span className="text-[#b8933f]">—</span>
                  Structural Foundations
                </li>
                <li className="flex items-start gap-3 text-sm text-[#ede7d9]">
                  <span className="text-[#b8933f]">—</span>
                  Ingredient Intelligence
                </li>
                <li className="flex items-start gap-3 text-sm text-[#ede7d9]">
                  <span className="text-[#b8933f]">—</span>
                  Layering Fundamentals
                </li>
                <li className="flex items-start gap-3 text-sm text-[#ede7d9]">
                  <span className="text-[#b8933f]">—</span>
                  Digital Workbook
                </li>
              </ul>
              <a href={STRIPE_CHECKOUT_URL} target="_blank" rel="noopener noreferrer" className="w-full btn-primary text-center block">
                Enroll Now
              </a>
            </div>
            
            {/* Executive Track */}
            <div className="pricing-card bg-[#0e0c0b]/60 p-10">
              <div className="text-[11px] uppercase tracking-[3px] text-[#b8933f] mb-5">
                Tier I–IV
              </div>
              <h3 className="font-display text-2xl font-normal text-[#f5f0e8] mb-3">
                Executive Track
              </h3>
              <div className="font-display text-5xl font-light text-[#d4aa5a] mb-2">
                $2,997
              </div>
              <div className="text-sm text-[#7a6e62] mb-8">
                or 4 × $850 CAD
              </div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start gap-3 text-sm text-[#ede7d9]">
                  <span className="text-[#b8933f]">—</span>
                  Full Structural Mastery
                </li>
                <li className="flex items-start gap-3 text-sm text-[#ede7d9]">
                  <span className="text-[#b8933f]">—</span>
                  Ingredient Architecture
                </li>
                <li className="flex items-start gap-3 text-sm text-[#ede7d9]">
                  <span className="text-[#b8933f]">—</span>
                  Consultation Design
                </li>
                <li className="flex items-start gap-3 text-sm text-[#ede7d9]">
                  <span className="text-[#b8933f]">—</span>
                  Case Strategy
                </li>
                <li className="flex items-start gap-3 text-sm text-[#ede7d9]">
                  <span className="text-[#b8933f]">—</span>
                  Everything in Professional
                </li>
              </ul>
              <a href={STRIPE_CHECKOUT_URL} target="_blank" rel="noopener noreferrer" className="w-full btn-primary text-center block">
                Enroll Now
              </a>
            </div>
            
            {/* Full Certification - Featured */}
            <div className="pricing-card featured p-10 relative">
              <div className="absolute -top-px left-1/2 -translate-x-1/2 bg-[#b8933f] text-[#0e0c0b] text-[10px] uppercase tracking-[2px] font-semibold px-4 py-1.5">
                Most Popular
              </div>
              <div className="text-[11px] uppercase tracking-[3px] text-[#b8933f] mb-5">
                Full Certification
              </div>
              <h3 className="font-display text-2xl font-normal text-[#f5f0e8] mb-3">
                Executive Beauty Architect™
              </h3>
              <div className="font-display text-5xl font-light text-[#d4aa5a] mb-1">
                $2,997
              </div>
              <div className="text-sm text-[#7a6e62] line-through mb-2">
                $4,500 CAD
              </div>
              <div className="text-sm text-[#7a6e62] mb-8">
                or 6 × $825 CAD
              </div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start gap-3 text-sm text-[#ede7d9]">
                  <span className="text-[#b8933f]">—</span>
                  All Six Tiers
                </li>
                <li className="flex items-start gap-3 text-sm text-[#ede7d9]">
                  <span className="text-[#b8933f]">—</span>
                  Full Examination
                </li>
                <li className="flex items-start gap-3 text-sm text-[#ede7d9]">
                  <span className="text-[#b8933f]">—</span>
                  Case Defense Review
                </li>
                <li className="flex items-start gap-3 text-sm text-[#ede7d9]">
                  <span className="text-[#b8933f]">—</span>
                  EBA™ Credential
                </li>
                <li className="flex items-start gap-3 text-sm text-[#ede7d9]">
                  <span className="text-[#b8933f]">—</span>
                  Digital Certificate
                </li>
                <li className="flex items-start gap-3 text-sm text-[#ede7d9]">
                  <span className="text-[#b8933f]">—</span>
                  Lifetime Access
                </li>
              </ul>
              <a href={STRIPE_CHECKOUT_URL} target="_blank" rel="noopener noreferrer" className="w-full btn-primary text-center block">
                Enroll — Founding Cohort
              </a>
            </div>
          </div>
          
          <div className="text-center mt-10">
            <p className="text-[11px] uppercase tracking-[2px] text-[#b8933f]">
              Limited case defense review windows per quarter. Founding cohort pricing will not return.
            </p>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section id="cta" className="py-40 bg-[#1a1714] text-center relative overflow-hidden">
        {/* Radial gradient background */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] rounded-full bg-[radial-gradient(circle,rgba(184,147,63,0.06)_0%,transparent_70%)] pointer-events-none" />
        
        <div className="max-w-3xl mx-auto px-6 relative z-10">
          <div className="text-[11px] uppercase tracking-[3px] text-[#b8933f] mb-6">
            The Decision
          </div>
          
          <h2 className="font-display text-5xl md:text-6xl font-light text-[#f5f0e8] mb-8">
            Stop Selling. Start <em className="text-[#d4aa5a] not-italic">Architecting.</em>
          </h2>
          
          <p className="text-base text-[#7a6e62] leading-relaxed mb-6 max-w-xl mx-auto">
            The beauty industry will continue to change. Products will evolve. Trends will shift. Client expectations will rise.
          </p>
          
          <p className="text-base text-[#7a6e62] leading-relaxed mb-10 max-w-xl mx-auto">
            What remains constant is the need for professionals who can think structurally, communicate clinically, and architect outcomes with confidence.
          </p>
          
          <p className="text-lg text-[#ede7d9] mb-12">
            That professional can be <span className="text-[#b8933f]">you.</span>
          </p>
          
          <div className="flex flex-wrap justify-center gap-4">
            <button onClick={() => window.open('mailto:enroll@ambitiouslyinstitute.com?subject=Executive Beauty Architect Certification Enrollment', '_blank')} className="btn-primary">
              Enroll in Certification
            </button>
            <button onClick={() => window.open('mailto:consult@ambitiouslyinstitute.com?subject=Certification Consultation Request', '_blank')} className="btn-secondary">
              Schedule a Consultation
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-16 bg-[#0e0c0b] border-t border-[#b8933f]/10">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid md:grid-cols-3 gap-12 mb-12">
            {/* Brand */}
            <div>
              <div className="font-display text-lg uppercase tracking-widest text-[#f5f0e8] mb-4">
                Ambitiously <span className="text-[#b8933f]">Institute</span>
              </div>
              <p className="text-sm text-[#7a6e62] leading-relaxed">
                Executive Beauty Architecture™ — Training professionals to think structurally, communicate clinically, and architect outcomes with authority.
              </p>
            </div>
            
            {/* Navigation */}
            <div>
              <h4 className="text-[11px] uppercase tracking-[2px] text-[#b8933f] mb-5">
                Navigation
              </h4>
              <ul className="space-y-3">
                <li>
                  <button onClick={() => scrollToSection('problem')} className="text-sm text-[#7a6e62] hover:text-[#ede7d9] transition-colors">
                    About
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollToSection('program')} className="text-sm text-[#7a6e62] hover:text-[#ede7d9] transition-colors">
                    Curriculum
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollToSection('investment')} className="text-sm text-[#7a6e62] hover:text-[#ede7d9] transition-colors">
                    Investment
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollToSection('cta')} className="text-sm text-[#7a6e62] hover:text-[#ede7d9] transition-colors">
                    Enroll
                  </button>
                </li>
              </ul>
            </div>
            
            {/* Legal */}
            <div>
              <h4 className="text-[11px] uppercase tracking-[2px] text-[#b8933f] mb-5">
                Legal
              </h4>
              <ul className="space-y-3">
                <li>
                  <span className="text-sm text-[#7a6e62] hover:text-[#ede7d9] transition-colors cursor-pointer">
                    Terms of Certification
                  </span>
                </li>
                <li>
                  <span className="text-sm text-[#7a6e62] hover:text-[#ede7d9] transition-colors cursor-pointer">
                    Privacy Policy
                  </span>
                </li>
                <li>
                  <span className="text-sm text-[#7a6e62] hover:text-[#ede7d9] transition-colors cursor-pointer">
                    Cookie Policy
                  </span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="pt-8 border-t border-[#b8933f]/10 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-xs text-[#7a6e62]/70">
              The Executive Beauty Architect™ Certification Program is an educational program designed to enhance professional knowledge. Completion does not grant medical licensure.
            </p>
            <p className="text-xs text-[#7a6e62]/50">
              © 2024 Ambitiously Institute. All Rights Reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
